import React,{Component} from 'react'
import { App } from './router.js';
export default class Home extends Component  { 
  render(){
    return (
        <App />
      )
  }
}